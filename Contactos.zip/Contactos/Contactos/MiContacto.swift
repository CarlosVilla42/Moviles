//
//  MiContacto.swift
//  Contacto
//
//  Created by Mac16 
//  Copyright © 2020 oscar. All rights reserved.
//

import Foundation

struct MiContacto {
    var nombre: String?
    var telefono: Int64?
    var direccion : String?
    
}
