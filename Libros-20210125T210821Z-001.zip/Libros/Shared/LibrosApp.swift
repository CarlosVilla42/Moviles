//
//  LibrosApp.swift
//  Shared
//
//  Created by Ivan Villa on 24/01/21.
//

import SwiftUI

@main
struct LibrosApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
