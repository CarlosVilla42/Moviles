//
//  MenuPrincipalViewController.swift
//  cocoapodsexampleCLTypingLabel
//
//  Created by Mac16.
//  Copyright © 2020 funcion. All rights reserved.
//

import UIKit
import FirebaseAuth
import SwiftUI
//import SwiftyJSON
//import SDWebImageSwiftUI
//import WebKit

class MenuPrincipalViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        navigationItem.hidesBackButton =  true
    }
    
    @IBAction func salirSesionButton(_ sender: UIBarButtonItem) {
        do {
            try Auth.auth().signOut()
            navigationController?.popToRootViewController(animated: true)
        } catch let signOutError as NSError {
      print ("Error al cerrar sesion...", signOutError)
            
    }
      
        
    }

}
