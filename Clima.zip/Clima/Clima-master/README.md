# Clima
Aplicación de Clima que consume una API
Para su mejor funcionamiento, solo es necesario presionar 2 veces el boton buscar la primera vez que se ejecute la aplicaciòn
